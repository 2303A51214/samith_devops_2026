const express = require("express");

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

let students = [];

/* ---------------- HOME PAGE ---------------- */

app.get("/", (req, res) => {
    res.send(`
    <!DOCTYPE html>
    <html>
    <head>
        <title>Student Management</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background: linear-gradient(135deg, #4e73df, #1cc88a);
                margin: 0;
                padding: 0;
                color: #333;
            }

            .container {
                width: 90%;
                max-width: 800px;
                margin: 40px auto;
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            }

            h2 {
                text-align: center;
                margin-bottom: 20px;
            }

            input {
                width: 100%;
                padding: 10px;
                margin: 8px 0;
                border-radius: 5px;
                border: 1px solid #ccc;
            }

            button {
                width: 100%;
                padding: 10px;
                background: #4e73df;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-size: 16px;
            }

            button:hover {
                background: #2e59d9;
            }

            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }

            table, th, td {
                border: 1px solid #ddd;
            }

            th, td {
                padding: 10px;
                text-align: center;
            }

            th {
                background: #4e73df;
                color: white;
            }

            .no-data {
                text-align: center;
                margin-top: 20px;
                color: gray;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Student Management System</h2>

            <form action="/add" method="POST">
                <input type="text" name="name" placeholder="Student Name" required>
                <input type="text" name="rollNumber" placeholder="Roll Number" required>
                <input type="number" name="age" placeholder="Age" required>
                <input type="text" name="course" placeholder="Course" required>
                <input type="text" name="contactNumber" placeholder="Contact Number" required>
                <button type="submit">Add Student</button>
            </form>

            ${students.length === 0 ? 
                "<p class='no-data'>No Students Added Yet</p>" 
                : `
                <table>
                    <tr>
                        <th>Name</th>
                        <th>Roll</th>
                        <th>Age</th>
                        <th>Course</th>
                        <th>Contact</th>
                    </tr>
                    ${students.map(s => `
                        <tr>
                            <td>${s.name}</td>
                            <td>${s.rollNumber}</td>
                            <td>${s.age}</td>
                            <td>${s.course}</td>
                            <td>${s.contactNumber}</td>
                        </tr>
                    `).join("")}
                </table>
                `
            }
        </div>
    </body>
    </html>
    `);
});

/* ---------------- ADD STUDENT ---------------- */

app.post("/add", (req, res) => {
    students.push(req.body);
    res.redirect("/");
});

/* ---------------- SERVER ---------------- */

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});