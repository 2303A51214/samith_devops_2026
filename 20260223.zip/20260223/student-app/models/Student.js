const express = require("express");
const bodyParser = require("body-parser");
const methodOverride = require("method-override");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride("_method"));
app.use(express.static("public"));

// Temporary in-memory storage
let students = [];

/* -------------------- REST API -------------------- */

// POST - Add new student
app.post("/students", (req, res) => {
    students.push(req.body);
    res.send("Student Added Successfully");
});

// GET - Get all students
app.get("/students", (req, res) => {
    res.json(students);
});

// GET - Get student by roll number
app.get("/students/:roll", (req, res) => {
    const student = students.find(s => s.rollNumber === req.params.roll);
    if (!student) return res.send("Student Not Found");
    res.json(student);
});

// PUT - Update student
app.put("/students/:roll", (req, res) => {
    const student = students.find(s => s.rollNumber === req.params.roll);
    if (!student) return res.send("Student Not Found");

    Object.assign(student, req.body);
    res.send("Student Updated Successfully");
});

// DELETE - Delete student
app.delete("/students/:roll", (req, res) => {
    students = students.filter(s => s.rollNumber !== req.params.roll);
    res.send("Student Deleted Successfully");
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});