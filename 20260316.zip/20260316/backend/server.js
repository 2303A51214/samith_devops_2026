const express = require("express")
const cors = require("cors")
const fs = require("fs")
const path = require("path")

const app = express()

app.use(cors())
app.use(express.json())

const DB = path.join(__dirname,"db.json")

/* READ DATABASE */

function readDB(){
 return JSON.parse(fs.readFileSync(DB))
}

/* WRITE DATABASE */

function writeDB(data){
 fs.writeFileSync(DB,JSON.stringify(data,null,2))
}

/* REGISTER USER */

app.post("/register",(req,res)=>{

let db = readDB()

const user = {
 id: Date.now(),
 name: req.body.name,
 email: req.body.email,
 password: req.body.password
}

db.users.push(user)

writeDB(db)

res.send("User Registered")

})

/* LOGIN USER */

app.post("/login",(req,res)=>{

let db = readDB()

const user = db.users.find(
u => u.email === req.body.email && u.password === req.body.password
)

if(user){
 res.json(user)
}else{
 res.status(401).send("Invalid Login")
}

})

/* ADD LOST OR FOUND ITEM */

app.post("/add-item",(req,res)=>{

let db = readDB()

if(!db.items){
    db.items = []
}

const item = {
 id: Date.now(),
 title: req.body.title,
 description: req.body.description,
 location: req.body.location,
 status: req.body.status,
 contact: req.body.contact
}

db.items.push(item)

writeDB(db)

res.send("Item Added Successfully")

})

/* GET ALL ITEMS (INDEX PAGE) */

app.get("/items",(req,res)=>{

let db = readDB()

res.json(db.items)

})

/* SEARCH ITEMS */

app.get("/search",(req,res)=>{

let db = readDB()

let items = db.items

if(req.query.keyword){
 items = items.filter(i =>
  i.title.toLowerCase().includes(req.query.keyword.toLowerCase())
 )
}

if(req.query.status){
 items = items.filter(i => i.status === req.query.status)
}

res.json(items)

})

/* DELETE ITEM (ADMIN) */

app.delete("/delete/:id",(req,res)=>{

let db = readDB()

db.items = db.items.filter(i => i.id != req.params.id)

writeDB(db)

res.send("Item Deleted")

})

/* START SERVER */

app.listen(5000,()=>{

console.log("Server running on http://localhost:5000")

})