const API = "http://localhost:5000"

/* POST ITEM */

function addItem(){

const title = document.getElementById("title").value
const description = document.getElementById("description").value
const location = document.getElementById("location").value
const status = document.getElementById("status").value
const contact = document.getElementById("contact").value

fetch(API + "/add-item",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
title,
description,
location,
status,
contact
})
})
.then(res=>res.text())
.then(data=>{
alert(data)

/* redirect to homepage */
window.location.href="index.html"

})

}

/* LOAD ITEMS */

function loadItems(){

fetch(API + "/items")

.then(res=>res.json())

.then(items=>{

let html=""

items.forEach(item=>{

html += `
<div class="col-md-4">
<div class="card shadow mb-4">
<div class="card-body">

<h5 class="card-title">${item.title}</h5>

<p>${item.description}</p>

<p><b>Status:</b> ${item.status}</p>

<p><b>Location:</b> ${item.location}</p>

<p><b>Contact:</b> ${item.contact}</p>

</div>
</div>
</div>
`

})

if(document.getElementById("items")){
document.getElementById("items").innerHTML = html
}

})

}

/* AUTO LOAD */

window.onload = loadItems